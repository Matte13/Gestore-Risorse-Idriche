'use strict';
class Azienda {

    constructor(id, nome) {

        this.id = id;
        this.nome = nome;
    }

}

module.exports = Azienda;