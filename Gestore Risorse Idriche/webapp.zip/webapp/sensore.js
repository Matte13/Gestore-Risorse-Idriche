'use strict';
class Sensore {

    constructor(id, tipo, idCampo) {

        this.id = id;
        this.tipo = tipo;
        this.idCampo= idCampo;
    }
}

module.exports = Sensore;