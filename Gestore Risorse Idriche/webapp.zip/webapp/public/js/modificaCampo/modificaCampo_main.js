"use strict";

const modificaCampoContainer = document.getElementById("modificaCampo");

const buttonContainer = document.getElementById("modifica");

let app = new modificaCampo_app(modificaCampoContainer, buttonContainer);