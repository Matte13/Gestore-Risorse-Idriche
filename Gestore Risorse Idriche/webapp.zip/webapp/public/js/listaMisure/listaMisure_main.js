"use strict";

const listaMisureContainer = document.getElementById("listaMisure");

let app = new listaMisure_app(listaMisureContainer);