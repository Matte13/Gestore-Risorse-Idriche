"use strict";

const listaPianiContainer = document.getElementById("listaPiani");

let app = new listaPiani_app(listaPianiContainer);