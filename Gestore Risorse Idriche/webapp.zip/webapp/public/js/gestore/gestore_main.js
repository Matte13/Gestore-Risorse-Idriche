"use strict";

const listaCampiAziendeContainer = document.getElementById("listaCampiAziende");

let app = new gestore_app(listaCampiAziendeContainer);