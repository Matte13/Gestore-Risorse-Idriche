'use strict';
class Configurazione{

    constructor(idAzienda, dettagliCampo,piani) {

        this.idAzienda = idAzienda;
        this.dettagliCampo = dettagliCampo;
        this.piani= piani;
    }
}

module.exports = Configurazione;